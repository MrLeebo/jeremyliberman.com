﻿$(function () {

	// Variable reference to the button on the form.
	var searchButton = $("#SearchButton");

	// Prevent query look-ups until the template is ready.
	// This takes practically no time at all and will probably
	// never be an issue, but better safe than sorry.
	searchButton.attr("disabled", "disabled");
	
    // Load the template for displaying opportunities.
    $.get("../templates/_topOpportunities.tmpl", function (template) {

        // Append the template to the page.
        $("#Content").append(template);
		
		// Now that the template is loaded, allow searches.
		searchButton.removeAttr("disabled");
    });

	searchButton.click(function() {

		// Prevent multiple searches by disabling the button until we get the result.
		searchButton.attr("disabled", "disabled");

		// Variable for the container where opportunities are to be displayed.
		var container = $("#TopOpportunitiesContainer");
	
		// Format of an HTML message to let the user know the site is running a query.
		var loadingHtml = "Loading...<div class=\"ui-icon ui-icon-clock\" style=\"padding: inherit inherit inherit 20px\"></div>"
	
		// Show the loading message.
		container.html(loadingHtml);
	
		// Retrieve the query.
		var query = { query: $("#QueryInput").val() };

        // Fetch the top opportunities and render the results within 
		// a templated accordion widget using jQuery's Templates and 
		// UI extensions.
        $.getJSON("SummerJobsRelay.php", query, function (json) {

			// Allow searching.
			searchButton.removeAttr("disabled");

			// Obligatory error checking.
			if (json.error) {
				container.text(json.error.message.value);
				return;
			}
		
            // Seems kludgey, but this did the trick.
            var data = $.parseJSON($.parseJSON(json.d.getJobsListing));

            // Clear the results container to get rid of the loading message.
            container.empty();

            // Apply the template to the results.
            $("#TopOpportunitiesTemplate").tmpl(data.items).appendTo(container);

            // Apply hover states to the links inside the template.
            $('.link').hover(
              function () { $(this).addClass('ui-state-hover'); },
              function () { $(this).removeClass('ui-state-hover'); }
            );

            // Apply the accordian effect. First we 'destroy' it in case the 
			// accordion has already been initialized. Otherwise, the control
			// breaks the second time you query it.
            container.accordion('destroy').accordion({
                collapsible: true,
                icons: false,
                autoHeight: false
            });
        });
	});	
});