﻿<?php

# Query text
$query = $_GET["query"];

# Initialize the URL.
$root = 'http://api.dol.gov';
$nycFilter = "?format=%27json%27&query=%27$query%27&employmentType=&region=%27NY%27&locality=%27New%20York%27&zip=&skipCount=1";
$uri = "/V1/SummerJobs/getJobsListing$nycFilter";

# Create a handle of cURL.
$ch = curl_init("$root$uri");

# Initialize the timestamp and API key.
$timestamp = gmdate("Y-m-d\TH:i:s\Z");
$apiKey = "efe8b0a7-28e4-4e29-9fe4-a8393ca44349";

# Compute the signature.
$sharedSecret = "participate in code sprint";
$authorizationString = "$uri&Timestamp=$timestamp&ApiKey=$apiKey";
$signature = hash_hmac('sha1', $authorizationString, $sharedSecret);

# Format the authorization header.
$headers = array (
	"Authorization: Timestamp=$timestamp&ApiKey=$apiKey&Signature=$signature",
	"Accept: application/json"
);

# Configure cURL.
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Submit the request.
$result = curl_exec($ch);
curl_close($ch);

# Return the result!
echo $result;

?>